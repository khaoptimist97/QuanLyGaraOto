﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QuanLyGaraOto.DTO
{
    public class Motor
    {
        public int IDBienSo { get; set; }
        
        public string TenChuXe { get; set; }


        public string DiaChi { get; set; }


        public string DienThoai { get; set; }

        public int? IDHieuXe { get; set; }
        public int? TienNo { get; set; }
    }
}